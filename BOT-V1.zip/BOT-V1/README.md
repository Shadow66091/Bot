# File mình share thuộc dạng ngon ở thời điểm hiện tại. Treo mượt không lỗi nên hãy giữ nguyên credit giúp mình nhé. 🌸

## Nhớ hãy fork (remix) đúng nguồn (@khoi0603k) tránh lỗi ✔

### Liên hệ mình qua:
- Facebook🪐 : Lương Trường Khôi
- Telegram🎶 : TrKhoi_Media
```
                  .----.
      .---------. | == |
      |.-"""""-.| |----|
      ||       || | == |
      ||       || |----|
      |'-.....-'| |::::|
      `"")---(""` |___.|
     /:::::::::::\" _  "
    /:::=======:::\`\`\
    `"""""""""""""`  '-'
```
### update 02/03/2025
- Tối ưu pack
- Fix nhiều lắm bạn trải nghiệm đi nhé
### update 28/02/2025
- Fix quyền
- Thay rent.js
### update 26/02/2025
- Fix menu, help không dùng được
### update 25/02/2025:
- Up thêm mdl (lệnh)
### update 24/02/2025:
- Fix lỗi thiếu ảnh cho lệnh baucua